package com.niit.mylogin.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.mylogin.dao.UserDAO;
import com.niit.mylogin.model.Address;
import com.niit.mylogin.model.RegisterModel;
import com.niit.mylogin.model.User;


@Component
public class RegisterHandler {

	@Autowired
	private UserDAO userDAO;
	
	public RegisterModel init(){
		
		return new RegisterModel();
	}
	
	public void addUser(RegisterModel registerModel, User user){
		
	registerModel.setUser(user);	
	}
	
	public void addBilling(RegisterModel registerModel, Address billing){
		
		registerModel.setBilling(billing);	
		}
	
	public String saveAll(RegisterModel model){
		
		String transitionValue="success";
		
		//fetch the user
		User user=model.getUser();
		
		
		//save the user
		
		userDAO.addUser(user);
		
		//get address
		
		Address billing = model.getBilling();
		billing.setUser(user);
		billing.setBilling(true);

		userDAO.addAddress(billing);
		
		return transitionValue;
	}
	
}
