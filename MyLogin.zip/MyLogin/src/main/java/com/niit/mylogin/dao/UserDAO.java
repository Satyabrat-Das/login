package com.niit.mylogin.dao;

import com.niit.mylogin.model.Address;
import com.niit.mylogin.model.User;



public interface UserDAO {

	
	boolean addUser(User user);
	
     User getByEmail(String email);
	
	boolean addAddress(Address address);


}
