$(function() {

	switch (menu) {
	case 'About Us':
		$('#about').addClass('active');
		break;

	case 'Contact Us':
		$('#contact').addClass('active');
		break;
	
	case 'My Product':
		$('#viewproducts').addClass('active');
		break;
		
	case 'Manage Products':
		$('#manageProducts').addClass('active');
		break;
	default:
		$('#home').addClass('active');
		$('#a_' + menu).addClass('active');
		break;
	}
	
	
	//to tackle csrf token
	var token = $('meta[name="_csrf"]').attr('content');
	var header = $('meta[name="_csrf_header"]').attr('content');

	
	
	if(token.length >0 && header.length > 0){
		
		//set the token header for ajax request
		
		$(document).ajaxSend(function(e, xhr, options){
			
			xhr.setRequestHeader(header,token);
		});
		
	}
	//code for Jquery dataTable
	//create DataSet
	

	
//validation for login
	var $loginForm = $('#loginForm');
	
	if($loginForm.length){
		
		$loginForm.validate({
			
			rules:{
						username:{
								required:true,
								email:true
							},
		              password:{
		            	  	required:true
			
		              			}
				
			     },
			     messages:{
			    	 username:{
			    		 required:'Plz give your  UserName',
			    		 email:'Plz Give Your Email id !!'
			    	 },
			    	 password:{
			    		 required:'Enter Your Password',
			    	 },
			    	 
			     },
			     errorElement:'em',
			     errorPlacement: function(error,element){
			    	 //add the class of help-block
			    	 error.addClass('help-block');
			    	 
			    	 //add error element after input element
			    	 error.insertAfter(element);
			     }
		    });
	      }
	
	
	
	
	
	
        });